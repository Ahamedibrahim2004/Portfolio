"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Mail, Github, Linkedin, GraduationCap, Briefcase, Code, Brain, Phone } from "lucide-react"
import { useScrollAnimation } from "@/hooks/use-scroll-animation"
import { ScrollToTop } from "@/components/scroll-to-top"
import { useEffect, useState } from "react"

export default function Portfolio() {
  const [heroRef, heroVisible] = useScrollAnimation(0.1)
  const [aboutRef, aboutVisible] = useScrollAnimation(0.1)
  const [projectsRef, projectsVisible] = useScrollAnimation(0.1)
  const [skillsRef, skillsVisible] = useScrollAnimation(0.1)
  const [contactRef, contactVisible] = useScrollAnimation(0.1)
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 scroll-smooth">
      {/* Header with scroll effect */}
      <header
        className={`fixed top-0 w-full z-40 transition-all duration-300 ${
          scrollY > 50 ? "bg-white/95 backdrop-blur-md shadow-lg" : "bg-transparent"
        }`}
      >
        <div className="container mx-auto px-4 py-4">
          <nav className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-slate-800">Ahamed Ibrahim M</h1>
            <div className="hidden md:flex gap-6">
              <button
                onClick={() => scrollToSection("about")}
                className="text-slate-600 hover:text-slate-800 transition-colors"
              >
                About
              </button>
              <button
                onClick={() => scrollToSection("projects")}
                className="text-slate-600 hover:text-slate-800 transition-colors"
              >
                Projects
              </button>
              <button
                onClick={() => scrollToSection("skills")}
                className="text-slate-600 hover:text-slate-800 transition-colors"
              >
                Skills
              </button>
              <button
                onClick={() => scrollToSection("contact")}
                className="text-slate-600 hover:text-slate-800 transition-colors"
              >
                Contact
              </button>
            </div>
            <div className="flex gap-4">
              <Button variant="outline" size="sm" asChild>
                <a href="mailto:sathikibrahim143@gmail.com">
                  <Mail className="w-4 h-4 mr-2" />
                  Contact
                </a>
              </Button>
              <Button size="sm" asChild>
                <a href="tel:+919003750173">
                  <Phone className="w-4 h-4 mr-2" />
                  Call Me
                </a>
              </Button>
            </div>
          </nav>
        </div>
      </header>

      {/* Hero Section with parallax effect */}
      <section
        ref={heroRef}
        className="pt-32 pb-20 px-4 relative overflow-hidden"
        style={{
          transform: `translateY(${scrollY * 0.5}px)`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-blue-50 to-purple-50 opacity-50"></div>
        <div className="container mx-auto text-center relative z-10">
          <div
            className={`mb-8 transition-all duration-1000 ${
              heroVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            <div className="w-32 h-32 rounded-full mx-auto mb-6 overflow-hidden border-4 border-white shadow-xl hover:scale-110 transition-all duration-500 animate-float">
              <img src="/profile.png" alt="Ahamed Ibrahim M" className="w-full h-full object-cover" />
            </div>
            <h1
              className={`text-5xl font-bold text-slate-800 mb-4 transition-all duration-1000 delay-200 ${
                heroVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
              }`}
            >
              Ahamed Ibrahim M
            </h1>
            <p
              className={`text-xl text-slate-600 mb-6 max-w-2xl mx-auto transition-all duration-1000 delay-400 ${
                heroVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
              }`}
            >
              Data Science & AI Enthusiast | Computer Science Graduate | Machine Learning Developer
            </p>
            <div
              className={`flex justify-center gap-4 mb-8 transition-all duration-1000 delay-600 ${
                heroVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
              }`}
            >
              <Badge variant="secondary" className="px-4 py-2 animate-pulse-slow">
                <Brain className="w-4 h-4 mr-2" />
                Data Science
              </Badge>
              <Badge variant="secondary" className="px-4 py-2 animate-pulse-slow">
                <Code className="w-4 h-4 mr-2" />
                Machine Learning
              </Badge>
              <Badge variant="secondary" className="px-4 py-2 animate-pulse-slow">
                <GraduationCap className="w-4 h-4 mr-2" />
                Computer Science
              </Badge>
            </div>
            <div
              className={`transition-all duration-1000 delay-800 ${
                heroVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
              }`}
            >
              <Button
                size="lg"
                className="mr-4 hover:scale-105 transition-all duration-300"
                onClick={() => scrollToSection("projects")}
              >
                View My Work
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="hover:scale-105 transition-all duration-300 bg-transparent"
                onClick={() => scrollToSection("contact")}
              >
                Get In Touch
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" ref={aboutRef} className="py-16 px-4 bg-white relative">
        <div className="container mx-auto">
          <h2
            className={`text-3xl font-bold text-center mb-12 text-slate-800 transition-all duration-1000 ${
              aboutVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            About Me
          </h2>
          <div className="max-w-4xl mx-auto">
            <p
              className={`text-lg text-slate-600 mb-8 leading-relaxed transition-all duration-1000 delay-200 ${
                aboutVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
              }`}
            >
              I'm a passionate Computer Science graduate with a strong foundation in data science and artificial
              intelligence. Currently pursuing advanced studies in Data Science & AI at Datamites Institute and MCA at
              Measi Institute Of Information Technology. I have hands-on experience in machine learning projects and a
              growing expertise in predictive modeling and data analysis.
            </p>

            <div className="grid md:grid-cols-2 gap-8">
              <Card
                className={`hover:shadow-lg hover:scale-105 transition-all duration-500 ${
                  aboutVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-10"
                }`}
              >
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <GraduationCap className="w-5 h-5 mr-2 text-blue-600" />
                    Education
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="animate-slide-in-left">
                    <h4 className="font-semibold text-slate-800">MCA (Pursuing)</h4>
                    <p className="text-slate-600">Measi Institute Of Information Technology</p>
                  </div>
                  <div className="animate-slide-in-left">
                    <h4 className="font-semibold text-slate-800">Data Science & AI (Pursuing)</h4>
                    <p className="text-slate-600">Datamites Institute</p>
                  </div>
                  <div className="animate-slide-in-left">
                    <h4 className="font-semibold text-slate-800">B.Sc Computer Science</h4>
                    <p className="text-slate-600">Completed</p>
                  </div>
                </CardContent>
              </Card>

              <Card
                className={`hover:shadow-lg hover:scale-105 transition-all duration-500 delay-200 ${
                  aboutVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"
                }`}
              >
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Briefcase className="w-5 h-5 mr-2 text-green-600" />
                    Experience
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="animate-slide-in-right">
                    <h4 className="font-semibold text-slate-800">Software Development Intern</h4>
                    <p className="text-slate-600">Evolve IT Solution Company</p>
                    <p className="text-sm text-slate-500">1 Month Internship</p>
                    <p className="text-sm text-slate-600 mt-2">
                      Gained practical experience in software development and worked on real-world projects.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" ref={projectsRef} className="py-16 px-4 bg-slate-50 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-50/30 to-purple-50/30"></div>
        <div className="container mx-auto relative z-10">
          <h2
            className={`text-3xl font-bold text-center mb-12 text-slate-800 transition-all duration-1000 ${
              projectsVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            Machine Learning Projects
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {[
              {
                title: "Cell Phone Price Prediction",
                description: "Machine Learning model to predict cell phone prices based on features and specifications",
                icon: Brain,
                color: "purple",
                tags: ["Python", "Scikit-learn", "Pandas", "Regression"],
                delay: "delay-100",
              },
              {
                title: "Customer Transaction Prediction",
                description: "Predictive model to analyze and forecast customer transaction patterns",
                icon: Brain,
                color: "blue",
                tags: ["Python", "Machine Learning", "Data Analysis", "Classification"],
                delay: "delay-200",
              },
              {
                title: "Hospital Stay Prediction",
                description: "ML model to predict patient hospital stay duration for better resource planning",
                icon: Brain,
                color: "green",
                tags: ["Python", "Healthcare AI", "Predictive Analytics", "Regression"],
                delay: "delay-300",
              },
              {
                title: "Additional ML Project",
                description: "Fourth machine learning project showcasing diverse problem-solving skills",
                icon: Brain,
                color: "orange",
                tags: ["Python", "Data Science", "Machine Learning", "Analytics"],
                delay: "delay-400",
              },
            ].map((project, index) => (
              <Card
                key={index}
                className={`hover:shadow-xl hover:scale-105 transition-all duration-500 animate-bounce-in ${project.delay} ${
                  projectsVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
                }`}
              >
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <project.icon className={`w-5 h-5 mr-2 text-${project.color}-600`} />
                    {project.title}
                  </CardTitle>
                  <CardDescription>{project.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tags.map((tag, tagIndex) => (
                      <Badge key={tagIndex} variant="outline" className="animate-fade-in-tag">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    asChild
                    className="hover:scale-105 transition-all duration-300 bg-transparent"
                  >
                    <a
                      href="https://github.com/Ahamedibrahim2004/Data-science-project-"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Github className="w-4 h-4 mr-2" />
                      View Code
                    </a>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" ref={skillsRef} className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <h2
            className={`text-3xl font-bold text-center mb-12 text-slate-800 transition-all duration-1000 ${
              skillsVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            Technical Skills
          </h2>
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  title: "Programming Languages",
                  skills: [
                    { name: "Python", color: "blue" },
                    { name: "Java", color: "orange" },
                    { name: "JavaScript", color: "yellow" },
                  ],
                  delay: "delay-100",
                },
                {
                  title: "Web Technologies",
                  skills: [
                    { name: "HTML", color: "red" },
                    { name: "CSS", color: "blue" },
                    { name: "Bootstrap", color: "purple" },
                  ],
                  delay: "delay-200",
                },
                {
                  title: "Data Science & AI",
                  skills: [
                    { name: "Machine Learning", color: "green" },
                    { name: "Data Analysis", color: "indigo" },
                    { name: "Predictive Modeling", color: "pink" },
                  ],
                  delay: "delay-300",
                },
              ].map((category, index) => (
                <Card
                  key={index}
                  className={`hover:shadow-lg hover:scale-105 transition-all duration-500 ${category.delay} ${
                    skillsVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
                  }`}
                >
                  <CardHeader>
                    <CardTitle className="text-center">{category.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2 justify-center">
                      {category.skills.map((skill, skillIndex) => (
                        <Badge
                          key={skillIndex}
                          className={`bg-${skill.color}-100 text-${skill.color}-800 animate-skill-bounce`}
                          style={{ animationDelay: `${skillIndex * 0.1}s` }}
                        >
                          {skill.name}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section
        id="contact"
        ref={contactRef}
        className="py-16 px-4 bg-gradient-to-r from-slate-800 to-slate-900 text-white relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/20 to-purple-900/20"></div>
        <div className="container mx-auto text-center relative z-10">
          <h2
            className={`text-3xl font-bold mb-8 transition-all duration-1000 ${
              contactVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            Get In Touch
          </h2>
          <p
            className={`text-xl text-slate-300 mb-8 max-w-2xl mx-auto transition-all duration-1000 delay-200 ${
              contactVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            I'm always interested in new opportunities and collaborations in data science and AI. Let's connect and
            discuss how we can work together!
          </p>
          <div
            className={`flex flex-wrap justify-center gap-6 mb-8 transition-all duration-1000 delay-400 ${
              contactVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            {[
              {
                href: "mailto:sathikibrahim143@gmail.com",
                icon: Mail,
                text: "sathikibrahim143@gmail.com",
                delay: "delay-100",
              },
              {
                href: "https://www.linkedin.com/in/ahamed-ibrahim-273733325",
                icon: Linkedin,
                text: "LinkedIn",
                delay: "delay-200",
              },
              {
                href: "https://github.com/Ahamedibrahim2004/Data-science-project-",
                icon: Github,
                text: "GitHub",
                delay: "delay-300",
              },
              {
                href: "tel:+919003750173",
                icon: Phone,
                text: "+91 9003750173",
                delay: "delay-400",
              },
            ].map((contact, index) => (
              <Button
                key={index}
                variant="outline"
                className={`text-white border-white hover:bg-white hover:text-slate-800 bg-transparent hover:scale-110 transition-all duration-300 animate-contact-bounce ${contact.delay}`}
                asChild
              >
                <a
                  href={contact.href}
                  target={contact.href.startsWith("http") ? "_blank" : undefined}
                  rel={contact.href.startsWith("http") ? "noopener noreferrer" : undefined}
                >
                  <contact.icon className="w-4 h-4 mr-2" />
                  {contact.text}
                </a>
              </Button>
            ))}
          </div>

          <div
            className={`grid md:grid-cols-2 gap-6 max-w-2xl mx-auto mt-8 text-slate-300 transition-all duration-1000 delay-600 ${
              contactVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            <div className="flex items-center justify-center gap-2 animate-pulse-slow">
              <Mail className="w-5 h-5" />
              <span>sathikibrahim143@gmail.com</span>
            </div>
            <div className="flex items-center justify-center gap-2 animate-pulse-slow">
              <Phone className="w-5 h-5" />
              <span>+91 9003750173</span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-8 px-4">
        <div className="container mx-auto text-center">
          <p>&copy; 2024 Ahamed Ibrahim M. All rights reserved.</p>
          <p className="mt-2">Built with React, Next.js, and Tailwind CSS</p>
        </div>
      </footer>

      <ScrollToTop />
    </div>
  )
}
